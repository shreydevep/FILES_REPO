import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import ChatSidebar from "@/components/chat-sidebar";
import ChatArea from "@/components/chat-area";
import SystemInstructionsPanel from "@/components/system-instructions-panel";
import type { Chat } from "@shared/schema";

export default function ChatPage() {
  const [currentChatId, setCurrentChatId] = useState<number | null>(null);
  const [showSystemPanel, setShowSystemPanel] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);

  const { data: chats = [] } = useQuery<Chat[]>({
    queryKey: ["/api/chats"]
  });

  // Auto-select first chat if none selected
  useEffect(() => {
    if (chats.length > 0 && !currentChatId) {
      setCurrentChatId(chats[0].id);
    }
  }, [chats, currentChatId]);

  const currentChat = chats.find(chat => chat.id === currentChatId);

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile sidebar overlay */}
      {showSidebar && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setShowSidebar(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed lg:relative lg:translate-x-0 z-50 lg:z-0
        w-80 h-full transition-transform duration-300 ease-in-out
        ${showSidebar ? 'translate-x-0' : '-translate-x-full'}
        lg:flex
      `}>
        <ChatSidebar
          chats={chats}
          currentChatId={currentChatId}
          onChatSelect={setCurrentChatId}
          onCloseSidebar={() => setShowSidebar(false)}
        />
      </div>

      {/* Main chat area */}
      <div className="flex-1 flex flex-col min-w-0">
        <ChatArea
          currentChat={currentChat}
          onToggleSidebar={() => setShowSidebar(!showSidebar)}
          onToggleSystemPanel={() => setShowSystemPanel(!showSystemPanel)}
          onChatCreated={setCurrentChatId}
        />
      </div>

      {/* System instructions panel */}
      {showSystemPanel && (
        <div className="w-80 flex-shrink-0">
          <SystemInstructionsPanel
            onClose={() => setShowSystemPanel(false)}
          />
        </div>
      )}
    </div>
  );
}
