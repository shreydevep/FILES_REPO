import { User, Bot, Copy, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import type { Message } from "@shared/schema";

interface MessageBubbleProps {
  message: Message;
}

export default function MessageBubble({ message }: MessageBubbleProps) {
  const { toast } = useToast();
  
  const isUser = message.role === 'user';
  const isAssistant = message.role === 'assistant';

  const handleCopy = () => {
    navigator.clipboard.writeText(message.content);
    toast({
      title: "Copied",
      description: "Message copied to clipboard"
    });
  };

  const formatTime = (timestamp: Date | null) => {
    if (!timestamp) return '';
    return new Date(timestamp).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  return (
    <div className="flex gap-4 animate-fade-in">
      <div className={`
        w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0
        ${isUser ? 'bg-gray-200' : 'bg-brand-green'}
      `}>
        {isUser ? (
          <User className="w-4 h-4 text-gray-600" />
        ) : (
          <Bot className="w-4 h-4 text-white" />
        )}
      </div>
      
      <div className="flex-1">
        <div className={`
          rounded-2xl px-4 py-3 max-w-3xl
          ${isUser 
            ? 'bg-brand-green text-white rounded-tl-sm' 
            : 'bg-chat-bg text-gray-900 rounded-tl-sm'
          }
        `}>
          <div className="whitespace-pre-wrap break-words">
            {message.content}
          </div>
        </div>
        
        <div className="flex items-center gap-3 mt-2">
          <p className="text-xs text-brand-gray">
            {formatTime(message.timestamp)}
          </p>
          
          {isAssistant && (
            <>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleCopy}
                className="text-xs text-brand-gray hover:text-gray-900 h-auto p-1"
              >
                <Copy className="w-3 h-3 mr-1" />
                Copy
              </Button>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  toast({
                    title: "Feature Coming Soon",
                    description: "Message regeneration will be available soon"
                  });
                }}
                className="text-xs text-brand-gray hover:text-gray-900 h-auto p-1"
              >
                <RotateCcw className="w-3 h-3 mr-1" />
                Regenerate
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
