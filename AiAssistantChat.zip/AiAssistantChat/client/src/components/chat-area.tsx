import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Menu, Trash2, Settings, Send, Bot } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import MessageBubble from "./message-bubble";
import type { Chat, Message } from "@shared/schema";

interface ChatAreaProps {
  currentChat: Chat | undefined;
  onToggleSidebar: () => void;
  onToggleSystemPanel: () => void;
  onChatCreated: (chatId: number) => void;
}

export default function ChatArea({
  currentChat,
  onToggleSidebar,
  onToggleSystemPanel,
  onChatCreated
}: ChatAreaProps) {
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: [`/api/chats/${currentChat?.id}/messages`],
    enabled: !!currentChat?.id
  });

  const createChatMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/chats", {
        title: "New Chat",
        systemInstructions: ""
      });
      return response.json();
    },
    onSuccess: (newChat) => {
      queryClient.invalidateQueries({ queryKey: ["/api/chats"] });
      onChatCreated(newChat.id);
    }
  });

  const sendMessageMutation = useMutation({
    mutationFn: async ({ chatId, content }: { chatId: number; content: string }) => {
      const response = await apiRequest("POST", `/api/chats/${chatId}/messages`, {
        content
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/chats/${currentChat?.id}/messages`] });
      queryClient.invalidateQueries({ queryKey: ["/api/chats"] });
      setMessage("");
      setIsLoading(false);
    },
    onError: () => {
      setIsLoading(false);
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive"
      });
    }
  });

  const handleSendMessage = async () => {
    if (!message.trim()) return;

    let chatId = currentChat?.id;
    
    // Create new chat if none exists
    if (!chatId) {
      try {
        const newChat = await createChatMutation.mutateAsync();
        chatId = newChat.id;
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to create chat",
          variant: "destructive"
        });
        return;
      }
    }

    setIsLoading(true);
    sendMessageMutation.mutate({ chatId: chatId!, content: message });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleClearChat = () => {
    // Simply clear the local state, don't delete the chat
    queryClient.setQueryData([`/api/chats/${currentChat?.id}/messages`], []);
    toast({
      title: "Success",
      description: "Conversation cleared"
    });
  };

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [message]);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleSidebar}
            className="lg:hidden"
          >
            <Menu className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-lg font-semibold text-gray-900">
              {currentChat?.title || "New Chat"}
            </h1>
            <p className="text-sm text-brand-gray">AI Assistant</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClearChat}
            disabled={messages.length === 0}
            title="Clear conversation"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggleSystemPanel}
            title="System instructions"
          >
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.length === 0 && !isLoading ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-brand-green rounded-full flex items-center justify-center mx-auto mb-4">
              <Bot className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">
              How can I help you today?
            </h2>
            <p className="text-brand-gray">
              Start a conversation by typing your message below.
            </p>
          </div>
        ) : (
          <>
            {messages.map((msg) => (
              <MessageBubble key={msg.id} message={msg} />
            ))}
            
            {isLoading && (
              <div className="flex gap-4 animate-fade-in">
                <div className="w-8 h-8 bg-brand-green rounded-full flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1">
                  <div className="bg-chat-bg rounded-2xl rounded-tl-sm px-4 py-3 max-w-3xl">
                    <div className="flex items-center gap-2">
                      <div className="flex gap-1">
                        <div className="w-2 h-2 bg-brand-gray rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-brand-gray rounded-full animate-bounce animation-delay-100"></div>
                        <div className="w-2 h-2 bg-brand-gray rounded-full animate-bounce animation-delay-200"></div>
                      </div>
                      <span className="text-brand-gray text-sm">AI is thinking...</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white border-t border-gray-200 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="relative flex items-end gap-3 bg-white border border-gray-200 rounded-2xl p-4 shadow-sm focus-within:border-brand-green focus-within:shadow-md transition-all">
            <Textarea
              ref={textareaRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type your message here... (Press Enter to send, Shift+Enter for new line)"
              className="flex-1 resize-none border-none outline-none shadow-none focus-visible:ring-0 max-h-32 min-h-0"
              rows={1}
              disabled={isLoading}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!message.trim() || isLoading}
              className="bg-brand-green hover:bg-green-600 text-white"
              size="sm"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs text-brand-gray mt-2 text-center">
            Press <kbd className="px-1.5 py-0.5 bg-gray-100 rounded text-xs">Enter</kbd> to send, 
            <kbd className="px-1.5 py-0.5 bg-gray-100 rounded text-xs ml-1">Shift</kbd> + <kbd className="px-1.5 py-0.5 bg-gray-100 rounded text-xs">Enter</kbd> for new line
          </p>
        </div>
      </div>
    </div>
  );
}
