import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, MessageCircle, Trash2, User, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Chat } from "@shared/schema";

interface ChatSidebarProps {
  chats: Chat[];
  currentChatId: number | null;
  onChatSelect: (chatId: number) => void;
  onCloseSidebar: () => void;
}

export default function ChatSidebar({
  chats,
  currentChatId,
  onChatSelect,
  onCloseSidebar
}: ChatSidebarProps) {
  const [deletingChatId, setDeletingChatId] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createChatMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/chats", {
        title: "New Chat",
        systemInstructions: ""
      });
      return response.json();
    },
    onSuccess: (newChat) => {
      queryClient.invalidateQueries({ queryKey: ["/api/chats"] });
      onChatSelect(newChat.id);
      onCloseSidebar();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create new chat",
        variant: "destructive"
      });
    }
  });

  const deleteChatMutation = useMutation({
    mutationFn: async (chatId: number) => {
      await apiRequest("DELETE", `/api/chats/${chatId}`);
    },
    onSuccess: (_, deletedChatId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/chats"] });
      
      // If deleted chat was current, select another one
      if (currentChatId === deletedChatId) {
        const remainingChats = chats.filter(chat => chat.id !== deletedChatId);
        if (remainingChats.length > 0) {
          onChatSelect(remainingChats[0].id);
        } else {
          onChatSelect(null);
        }
      }
      
      setDeletingChatId(null);
      toast({
        title: "Success",
        description: "Chat deleted successfully"
      });
    },
    onError: () => {
      setDeletingChatId(null);
      toast({
        title: "Error",
        description: "Failed to delete chat",
        variant: "destructive"
      });
    }
  });

  const handleDeleteChat = (chatId: number, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeletingChatId(chatId);
    deleteChatMutation.mutate(chatId);
  };

  return (
    <div className="w-full h-full bg-sidebar-bg border-r border-gray-200 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <Button
          onClick={() => createChatMutation.mutate()}
          disabled={createChatMutation.isPending}
          className="w-full flex items-center gap-3 justify-start bg-white text-gray-900 border border-gray-200 hover:bg-gray-50"
          variant="outline"
        >
          <Plus className="w-4 h-4 text-brand-green" />
          <span className="font-medium">New chat</span>
        </Button>
      </div>

      {/* Chat History */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="space-y-2">
          <h3 className="text-xs font-medium text-brand-gray uppercase tracking-wide mb-3">
            Recent Chats
          </h3>
          
          {chats.length === 0 ? (
            <div className="text-center py-8 text-brand-gray">
              <MessageCircle className="w-8 h-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No chats yet</p>
              <p className="text-xs">Create a new chat to get started</p>
            </div>
          ) : (
            chats.map((chat) => (
              <div
                key={chat.id}
                onClick={() => {
                  onChatSelect(chat.id);
                  onCloseSidebar();
                }}
                className={`
                  group flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors
                  ${currentChatId === chat.id ? 'bg-white shadow-sm' : 'hover:bg-white'}
                `}
              >
                <MessageCircle className="w-4 h-4 text-brand-gray flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {chat.title}
                  </p>
                  <p className="text-xs text-brand-gray truncate">
                    {chat.createdAt ? new Date(chat.createdAt).toLocaleDateString() : ''}
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={(e) => handleDeleteChat(chat.id, e)}
                  disabled={deletingChatId === chat.id}
                  className="opacity-0 group-hover:opacity-100 p-1 h-auto hover:bg-gray-100"
                >
                  <Trash2 className="w-3 h-3 text-brand-gray" />
                </Button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* User Profile */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-white cursor-pointer transition-colors">
          <div className="w-8 h-8 bg-brand-green rounded-full flex items-center justify-center">
            <User className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-gray-900">Demo User</p>
            <p className="text-xs text-brand-gray">demo@example.com</p>
          </div>
          <MoreHorizontal className="w-4 h-4 text-brand-gray" />
        </div>
      </div>
    </div>
  );
}
