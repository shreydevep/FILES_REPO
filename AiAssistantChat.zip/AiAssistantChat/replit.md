# AI Chat Application

## Overview

This is a full-stack AI chat application built with React, Express, and PostgreSQL. The application provides a ChatGPT-like interface where users can have conversations with an AI assistant, manage multiple chat sessions, and customize system instructions for different conversation styles.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for client-side routing
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **Database ORM**: Drizzle ORM
- **Database**: PostgreSQL (via Neon serverless)
- **AI Integration**: OpenAI GPT-4o API
- **Session Management**: In-memory storage with planned PostgreSQL persistence

## Key Components

### Database Schema
The application uses four main tables:
- **users**: User authentication (currently mock implementation)
- **chats**: Chat sessions with titles and system instructions
- **messages**: Individual messages with role (user/assistant/system) and content
- **system_instructions**: User preferences for AI behavior (role, style, temperature)

### Frontend Components
- **ChatSidebar**: Manages chat list, creation, and deletion
- **ChatArea**: Main chat interface with message display and input
- **MessageBubble**: Individual message rendering with copy functionality
- **SystemInstructionsPanel**: Configuration panel for AI behavior settings

### Backend Services
- **Storage Layer**: Abstracted storage interface with in-memory implementation
- **OpenAI Service**: Handles AI response generation with configurable parameters
- **Route Handlers**: RESTful API endpoints for chats, messages, and system instructions

## Data Flow

1. **Chat Creation**: User creates new chat → Backend generates chat record → Frontend updates chat list
2. **Message Flow**: User sends message → Stored in database → Sent to OpenAI API → AI response stored → Frontend displays conversation
3. **System Instructions**: User configures AI behavior → Settings stored per user → Applied to all new conversations

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Type-safe database queries and migrations
- **openai**: Official OpenAI API client
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework

### Development Tools
- **tsx**: TypeScript execution for development
- **esbuild**: Fast JavaScript bundler for production
- **drizzle-kit**: Database migration management

## Deployment Strategy

### Development Environment
- **Development Server**: Vite dev server with Express API proxy
- **Database**: PostgreSQL via environment variable `DATABASE_URL`
- **Hot Reload**: Full-stack development with automatic reloading

### Production Deployment
- **Build Process**: 
  1. Vite builds frontend to `dist/public`
  2. esbuild bundles server to `dist/index.js`
- **Runtime**: Node.js with Express serving both API and static files
- **Database**: PostgreSQL connection via environment variables
- **Platform**: Replit with autoscale deployment target

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **OPENAI_API_KEY**: OpenAI API authentication (required)
- **NODE_ENV**: Environment mode (development/production)

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- June 22, 2025. Initial setup
- June 22, 2025. Removed OpenAI integration per user request - replaced with simple pattern-based chat responses