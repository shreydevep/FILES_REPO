export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ChatCompletionOptions {
  messages: ChatMessage[];
  temperature?: number;
  maxTokens?: number;
  systemInstructions?: string;
}

export async function generateChatResponse(options: ChatCompletionOptions): Promise<string> {
  // Random dummy responses for demo purposes
  const dummyResponses = [
    "That's an interesting point! Let me think about that for a moment.",
    "I completely understand what you're saying. Here's my take on it.",
    "You've raised a great question. From my perspective, I'd say that's worth exploring further.",
    "Thanks for sharing that with me! It's fascinating how different people approach these topics.",
    "I appreciate you bringing this up. It reminds me of something I was thinking about earlier.",
    "That's a really thoughtful way to look at it. I hadn't considered that angle before.",
    "You know, that's exactly the kind of thing that makes conversations interesting.",
    "I find myself agreeing with you on this one. It's a compelling argument.",
    "That's a fair point, and I think there's definitely merit to what you're saying.",
    "Hmm, that's got me thinking. There are probably multiple ways to approach this.",
    "I love how you've framed that question. It really gets to the heart of the matter.",
    "You've touched on something important there. It's one of those topics that deserves more attention.",
    "That's a perspective I hadn't fully considered before. Thanks for sharing it!",
    "I think you're onto something with that observation. It's quite insightful.",
    "You've given me something to ponder. I appreciate the thoughtful conversation.",
    "That's the kind of thinking that leads to breakthrough moments, in my opinion.",
    "I'm glad you brought that up. It's exactly what we should be discussing.",
    "Your point about that is well taken. I think many people would find it relatable.",
    "That's a nuanced way to look at it, and I respect that approach.",
    "You've articulated something that I think a lot of people feel but don't express."
  ];
  
  // Add a small delay to simulate processing
  await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 1500));
  
  // Return a random response
  const randomIndex = Math.floor(Math.random() * dummyResponses.length);
  return dummyResponses[randomIndex];
}

export async function generateChatTitle(firstMessage: string): Promise<string> {
  // Generate a simple title based on the first few words
  const words = firstMessage.split(' ').slice(0, 5).join(' ');
  return words.length > 50 ? words.substring(0, 47) + '...' : words || "New Chat";
}
