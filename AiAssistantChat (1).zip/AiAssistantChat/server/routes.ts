import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { generateChatResponse, generateChatTitle } from "./services/chat";
import { insertChatSchema, insertMessageSchema, insertSystemInstructionsSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Mock user session - in production, implement proper authentication
  const MOCK_USER_ID = 1;

  // Create mock user if it doesn't exist
  const existingUser = await storage.getUser(MOCK_USER_ID);
  if (!existingUser) {
    await storage.createUser({
      username: "demo_user",
      password: "password"
    });
  }

  // Get all chats for the user
  app.get("/api/chats", async (req, res) => {
    try {
      const chats = await storage.getChatsByUserId(MOCK_USER_ID);
      res.json(chats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chats" });
    }
  });

  // Create a new chat
  app.post("/api/chats", async (req, res) => {
    try {
      const chatData = insertChatSchema.parse({
        ...req.body,
        userId: MOCK_USER_ID
      });
      
      const chat = await storage.createChat(chatData);
      res.json(chat);
    } catch (error) {
      res.status(400).json({ message: "Failed to create chat" });
    }
  });

  // Get a specific chat
  app.get("/api/chats/:id", async (req, res) => {
    try {
      const chatId = parseInt(req.params.id);
      const chat = await storage.getChat(chatId);
      
      if (!chat) {
        return res.status(404).json({ message: "Chat not found" });
      }
      
      res.json(chat);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chat" });
    }
  });

  // Delete a chat
  app.delete("/api/chats/:id", async (req, res) => {
    try {
      const chatId = parseInt(req.params.id);
      const deleted = await storage.deleteChat(chatId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Chat not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete chat" });
    }
  });

  // Get messages for a chat
  app.get("/api/chats/:id/messages", async (req, res) => {
    try {
      const chatId = parseInt(req.params.id);
      const messages = await storage.getMessagesByChatId(chatId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Send a message and get AI response
  app.post("/api/chats/:id/messages", async (req, res) => {
    try {
      const chatId = parseInt(req.params.id);
      const { content } = req.body;
      
      if (!content?.trim()) {
        return res.status(400).json({ message: "Message content is required" });
      }

      // Get chat to check if it exists and get system instructions
      const chat = await storage.getChat(chatId);
      if (!chat) {
        return res.status(404).json({ message: "Chat not found" });
      }

      // Save user message
      const userMessage = await storage.createMessage({
        chatId,
        role: "user",
        content: content.trim()
      });

      // Get conversation history
      const messages = await storage.getMessagesByChatId(chatId);
      const conversationHistory = messages
        .filter(msg => msg.role !== 'system')
        .map(msg => ({
          role: msg.role as 'user' | 'assistant',
          content: msg.content
        }));

      // Get system instructions
      const systemInstructions = await storage.getSystemInstructions(MOCK_USER_ID);
      let systemPrompt = "You are a helpful AI assistant.";
      
      if (systemInstructions) {
        systemPrompt = systemInstructions.role;
        if (systemInstructions.customInstructions) {
          systemPrompt += " " + systemInstructions.customInstructions;
        }
      }

      // Generate AI response
      const aiResponse = await generateChatResponse({
        messages: conversationHistory,
        systemInstructions: systemPrompt,
        temperature: systemInstructions ? parseFloat(systemInstructions.temperature) : 0.7
      });

      // Save AI response
      const assistantMessage = await storage.createMessage({
        chatId,
        role: "assistant",
        content: aiResponse
      });

      // Update chat title if this is the first message
      if (conversationHistory.length === 1) {
        const title = await generateChatTitle(content);
        await storage.updateChatTitle(chatId, title);
      }

      res.json({
        userMessage,
        assistantMessage
      });
    } catch (error) {
      console.error("Error in chat message:", error);
      res.status(500).json({ message: "Failed to process message" });
    }
  });

  // Get system instructions
  app.get("/api/system-instructions", async (req, res) => {
    try {
      const instructions = await storage.getSystemInstructions(MOCK_USER_ID);
      
      if (!instructions) {
        // Return default instructions
        return res.json({
          role: "You are a helpful AI assistant. Be concise and accurate in your responses.",
          style: "balanced",
          temperature: "0.7",
          customInstructions: ""
        });
      }
      
      res.json(instructions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch system instructions" });
    }
  });

  // Save system instructions
  app.post("/api/system-instructions", async (req, res) => {
    try {
      const instructionsData = insertSystemInstructionsSchema.parse({
        ...req.body,
        userId: MOCK_USER_ID
      });
      
      const instructions = await storage.saveSystemInstructions(instructionsData);
      res.json(instructions);
    } catch (error) {
      res.status(400).json({ message: "Failed to save system instructions" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
