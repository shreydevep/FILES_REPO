import { 
  users, chats, messages, systemInstructions,
  type User, type Chat, type Message, type SystemInstructions,
  type InsertUser, type InsertChat, type InsertMessage, type InsertSystemInstructions 
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createChat(chat: InsertChat): Promise<Chat>;
  getChat(id: number): Promise<Chat | undefined>;
  getChatsByUserId(userId: number): Promise<Chat[]>;
  updateChatTitle(id: number, title: string): Promise<Chat | undefined>;
  deleteChat(id: number): Promise<boolean>;
  
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByChatId(chatId: number): Promise<Message[]>;
  
  getSystemInstructions(userId: number): Promise<SystemInstructions | undefined>;
  saveSystemInstructions(instructions: InsertSystemInstructions): Promise<SystemInstructions>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private chats: Map<number, Chat>;
  private messages: Map<number, Message>;
  private systemInstructions: Map<number, SystemInstructions>;
  private currentUserId: number;
  private currentChatId: number;
  private currentMessageId: number;
  private currentSystemId: number;

  constructor() {
    this.users = new Map();
    this.chats = new Map();
    this.messages = new Map();
    this.systemInstructions = new Map();
    this.currentUserId = 1;
    this.currentChatId = 1;
    this.currentMessageId = 1;
    this.currentSystemId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createChat(insertChat: InsertChat): Promise<Chat> {
    const id = this.currentChatId++;
    const chat: Chat = {
      id,
      title: insertChat.title,
      userId: insertChat.userId!,
      systemInstructions: insertChat.systemInstructions!,
      createdAt: new Date(),
    };
    this.chats.set(id, chat);
    return chat;
  }

  async getChat(id: number): Promise<Chat | undefined> {
    return this.chats.get(id);
  }

  async getChatsByUserId(userId: number): Promise<Chat[]> {
    return Array.from(this.chats.values())
      .filter(chat => chat.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async updateChatTitle(id: number, title: string): Promise<Chat | undefined> {
    const chat = this.chats.get(id);
    if (chat) {
      const updatedChat = { ...chat, title };
      this.chats.set(id, updatedChat);
      return updatedChat;
    }
    return undefined;
  }

  async deleteChat(id: number): Promise<boolean> {
    const deleted = this.chats.delete(id);
    // Also delete associated messages
    Array.from(this.messages.entries())
      .filter(([_, message]) => message.chatId === id)
      .forEach(([messageId, _]) => this.messages.delete(messageId));
    return deleted;
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const message: Message = {
      id,
      role: insertMessage.role,
      content: insertMessage.content,
      chatId: insertMessage.chatId!,
      timestamp: new Date(),
    };
    this.messages.set(id, message);
    return message;
  }

  async getMessagesByChatId(chatId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.chatId === chatId)
      .sort((a, b) => (a.timestamp?.getTime() || 0) - (b.timestamp?.getTime() || 0));
  }

  async getSystemInstructions(userId: number): Promise<SystemInstructions | undefined> {
    return Array.from(this.systemInstructions.values())
      .find(instructions => instructions.userId === userId);
  }

  async saveSystemInstructions(insertInstructions: InsertSystemInstructions): Promise<SystemInstructions> {
    const existing = Array.from(this.systemInstructions.values())
      .find(instructions => instructions.userId === insertInstructions.userId);
    
    if (existing) {
      const updated = { ...existing, ...insertInstructions };
      this.systemInstructions.set(existing.id, updated);
      return updated;
    } else {
      const id = this.currentSystemId++;
      const instructions: SystemInstructions = {
        id,
        userId: insertInstructions.userId!,
        role: insertInstructions.role,
        style: insertInstructions.style,
        temperature: insertInstructions.temperature,
        customInstructions: insertInstructions.customInstructions || null,
      };
      this.systemInstructions.set(id, instructions);
      return instructions;
    }
  }
}

export const storage = new MemStorage();
