import { QueryClient } from "@tanstack/react-query";
import { mockApi } from "@/services/mockApi";

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});

// Mock API request function for compatibility
export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<{ json: () => Promise<any> }> {
  // Parse the URL to determine which mock API method to call
  const urlParts = url.split('/');
  
  if (url.includes('/api/chats') && method === 'GET' && urlParts.length === 3) {
    // GET /api/chats
    const chats = await mockApi.getChats();
    return { json: async () => chats };
  } else if (url.includes('/api/chats') && method === 'POST' && urlParts.length === 3) {
    // POST /api/chats
    const chat = await mockApi.createChat((data as any)?.title || "New Chat");
    return { json: async () => chat };
  } else if (url.includes('/api/chats') && method === 'DELETE' && urlParts.length === 4) {
    // DELETE /api/chats/:id
    const chatId = parseInt(urlParts[3]);
    await mockApi.deleteChat(chatId);
    return { json: async () => ({ success: true }) };
  } else if (url.includes('/messages') && method === 'POST') {
    // POST /api/chats/:id/messages
    const chatId = parseInt(urlParts[3]);
    const result = await mockApi.sendMessage(chatId, (data as any)?.content || "");
    return { json: async () => result };
  } else if (url.includes('/messages') && method === 'GET') {
    // GET /api/chats/:id/messages
    const chatId = parseInt(urlParts[3]);
    const messages = await mockApi.getMessages(chatId);
    return { json: async () => messages };
  } else if (url.includes('/system-instructions') && method === 'GET') {
    // GET /api/system-instructions
    const instructions = await mockApi.getSystemInstructions();
    return { json: async () => instructions };
  } else if (url.includes('/system-instructions') && method === 'POST') {
    // POST /api/system-instructions
    const instructions = await mockApi.saveSystemInstructions(data || {});
    return { json: async () => instructions };
  }
  
  throw new Error(`Mock API: Unsupported request ${method} ${url}`);
}
