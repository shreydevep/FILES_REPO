import type { Chat, Message, SystemInstructions } from "@shared/schema";
import dummyChats from "../data/dummy-chats.json";
import dummyMessages from "../data/dummy-messages.json";
import dummySystemInstructions from "../data/dummy-system-instructions.json";

// In-memory storage for client-side state
class MockApiService {
  private chats: Chat[] = dummyChats.map(chat => ({
    ...chat,
    userId: chat.userId || null,
    systemInstructions: chat.systemInstructions || null,
    createdAt: chat.createdAt ? new Date(chat.createdAt) : null
  }));
  private messages: Record<string, Message[]> = Object.fromEntries(
    Object.entries(dummyMessages).map(([chatId, msgs]) => [
      chatId,
      msgs.map(msg => ({
        ...msg,
        chatId: msg.chatId || null,
        timestamp: msg.timestamp ? new Date(msg.timestamp) : null
      }))
    ])
  );
  private systemInstructions = { ...dummySystemInstructions as SystemInstructions };
  private nextChatId = 4;
  private nextMessageId = 9;

  // Simulate API delay
  private delay(ms: number = 500) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Chat operations
  async getChats(): Promise<Chat[]> {
    await this.delay();
    return [...this.chats].sort((a, b) => 
      new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
    );
  }

  async getChat(id: number): Promise<Chat | null> {
    await this.delay();
    return this.chats.find(chat => chat.id === id) || null;
  }

  async createChat(title: string): Promise<Chat> {
    await this.delay();
    const newChat: Chat = {
      id: this.nextChatId++,
      title,
      userId: 1,
      systemInstructions: "You are a helpful AI assistant.",
      createdAt: new Date()
    };
    this.chats.push(newChat);
    this.messages[newChat.id.toString()] = [];
    return newChat;
  }

  async deleteChat(id: number): Promise<boolean> {
    await this.delay();
    const index = this.chats.findIndex(chat => chat.id === id);
    if (index !== -1) {
      this.chats.splice(index, 1);
      delete this.messages[id.toString()];
      return true;
    }
    return false;
  }

  async updateChatTitle(id: number, title: string): Promise<Chat | null> {
    await this.delay();
    const chat = this.chats.find(c => c.id === id);
    if (chat) {
      chat.title = title;
      return chat;
    }
    return null;
  }

  // Message operations
  async getMessages(chatId: number): Promise<Message[]> {
    await this.delay();
    return this.messages[chatId.toString()] || [];
  }

  async sendMessage(chatId: number, content: string): Promise<{ userMessage: Message; assistantMessage: Message }> {
    await this.delay(300);

    // Create user message
    const userMessage: Message = {
      id: this.nextMessageId++,
      chatId,
      role: "user",
      content,
      timestamp: new Date()
    };

    if (!this.messages[chatId.toString()]) {
      this.messages[chatId.toString()] = [];
    }
    this.messages[chatId.toString()].push(userMessage);

    // Generate AI response
    await this.delay(800 + Math.random() * 1500);
    
    const dummyResponses = [
      "That's an interesting point! Let me think about that for a moment.",
      "I completely understand what you're saying. Here's my take on it.",
      "You've raised a great question. From my perspective, I'd say that's worth exploring further.",
      "Thanks for sharing that with me! It's fascinating how different people approach these topics.",
      "I appreciate you bringing this up. It reminds me of something I was thinking about earlier.",
      "That's a really thoughtful way to look at it. I hadn't considered that angle before.",
      "You know, that's exactly the kind of thing that makes conversations interesting.",
      "I find myself agreeing with you on this one. It's a compelling argument.",
      "That's a fair point, and I think there's definitely merit to what you're saying.",
      "Hmm, that's got me thinking. There are probably multiple ways to approach this.",
    ];

    const assistantMessage: Message = {
      id: this.nextMessageId++,
      chatId,
      role: "assistant",
      content: dummyResponses[Math.floor(Math.random() * dummyResponses.length)],
      timestamp: new Date()
    };

    this.messages[chatId.toString()].push(assistantMessage);

    // Update chat title if this is the first message
    if (this.messages[chatId.toString()].length === 2) {
      const words = content.split(' ').slice(0, 5).join(' ');
      const title = words.length > 50 ? words.substring(0, 47) + '...' : words || "New Chat";
      await this.updateChatTitle(chatId, title);
    }

    return { userMessage, assistantMessage };
  }

  // System instructions operations
  async getSystemInstructions(): Promise<SystemInstructions> {
    await this.delay();
    return { ...this.systemInstructions };
  }

  async saveSystemInstructions(instructions: Partial<SystemInstructions>): Promise<SystemInstructions> {
    await this.delay();
    this.systemInstructions = {
      ...this.systemInstructions,
      ...instructions
    };
    return { ...this.systemInstructions };
  }
}

export const mockApi = new MockApiService();