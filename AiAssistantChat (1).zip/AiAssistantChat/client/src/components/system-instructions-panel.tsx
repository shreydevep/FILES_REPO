import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { mockApi } from "@/services/mockApi";
import { useToast } from "@/hooks/use-toast";

interface SystemInstructionsPanelProps {
  onClose: () => void;
}

export default function SystemInstructionsPanel({ onClose }: SystemInstructionsPanelProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: instructions, isLoading } = useQuery({
    queryKey: ['system-instructions'],
    queryFn: () => mockApi.getSystemInstructions(),
    staleTime: 0 // Always fetch fresh data
  });

  const [formData, setFormData] = useState({
    role: "",
    style: "balanced",
    temperature: "0.7",
    customInstructions: ""
  });

  // Update form data when instructions load
  useEffect(() => {
    if (instructions) {
      setFormData({
        role: instructions.role || "",
        style: instructions.style || "balanced",
        temperature: instructions.temperature || "0.7",
        customInstructions: instructions.customInstructions || ""
      });
    }
  }, [instructions]);

  const saveInstructionsMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return await mockApi.saveSystemInstructions(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['system-instructions'] });
      toast({
        title: "Success",
        description: "System instructions saved successfully"
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save system instructions",
        variant: "destructive"
      });
    }
  });

  const handleSave = () => {
    saveInstructionsMutation.mutate(formData);
  };

  const handleReset = () => {
    const defaultData = {
      role: "You are a helpful AI assistant. Be concise and accurate in your responses.",
      style: "balanced",
      temperature: "0.7",
      customInstructions: ""
    };
    setFormData(defaultData);
    saveInstructionsMutation.mutate(defaultData);
  };

  const temperatureValue = parseFloat(formData.temperature);
  const temperatureLabels = {
    0: "Focused",
    0.5: "Balanced", 
    1: "Creative"
  };

  if (isLoading) {
    return (
      <div className="w-full h-full bg-white border-l border-gray-200 flex items-center justify-center">
        <div className="text-brand-gray">Loading...</div>
      </div>
    );
  }

  return (
    <div className="w-full h-full bg-white border-l border-gray-200 flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-gray-900">System Instructions</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
        <p className="text-sm text-brand-gray mt-1">
          Customize how the AI assistant behaves
        </p>
      </div>

      {/* Form */}
      <div className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">
              System Role
            </label>
            <Textarea
              value={formData.role}
              onChange={(e) => setFormData(prev => ({ ...prev, role: e.target.value }))}
              placeholder="You are a helpful AI assistant. Be concise and accurate in your responses..."
              className="h-32 resize-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">
              Response Style
            </label>
            <Select
              value={formData.style}
              onValueChange={(value) => setFormData(prev => ({ ...prev, style: value }))}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="balanced">Balanced</SelectItem>
                <SelectItem value="concise">Concise</SelectItem>
                <SelectItem value="detailed">Detailed</SelectItem>
                <SelectItem value="creative">Creative</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">
              Temperature ({temperatureValue})
            </label>
            <div className="space-y-2">
              <Slider
                value={[temperatureValue]}
                onValueChange={([value]) => setFormData(prev => ({ ...prev, temperature: value.toString() }))}
                max={1}
                min={0}
                step={0.1}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-brand-gray">
                <span>Focused</span>
                <span>Balanced</span>
                <span>Creative</span>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-900 mb-2">
              Custom Instructions
            </label>
            <Textarea
              value={formData.customInstructions}
              onChange={(e) => setFormData(prev => ({ ...prev, customInstructions: e.target.value }))}
              placeholder="Add any specific instructions or constraints..."
              className="h-24 resize-none"
            />
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200 space-y-3">
        <Button
          onClick={handleSave}
          disabled={saveInstructionsMutation.isPending}
          className="w-full bg-brand-green hover:bg-green-600 text-white"
        >
          {saveInstructionsMutation.isPending ? "Saving..." : "Save Instructions"}
        </Button>
        <Button
          onClick={handleReset}
          disabled={saveInstructionsMutation.isPending}
          variant="outline"
          className="w-full"
        >
          Reset to Default
        </Button>
      </div>
    </div>
  );
}
